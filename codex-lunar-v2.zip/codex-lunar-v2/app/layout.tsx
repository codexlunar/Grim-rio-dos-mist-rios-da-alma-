import './style.css';
export const metadata={title:'Códex Lunar | Grimório da Alma',description:'Uma experiência simbólica de autoconhecimento numerológico.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body>{children}</body></html>}
