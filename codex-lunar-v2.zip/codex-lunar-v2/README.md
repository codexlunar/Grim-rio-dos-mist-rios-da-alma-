# Códex Lunar v2 — protótipo funcional

Site Next.js com formulário de nascimento, cálculos numerológicos pitagóricos, mandala SVG interativa, prévia gratuita, 12 câmaras (11 bloqueadas), catálogo de 40 tradições e apresentação de R$ 15,00.

## Executar

Instale Node.js 20+, execute `npm install` e `npm run dev`. Acesse http://localhost:3000.

## Limites importantes

- **Não há cobrança real** nem botão de pagamento ativo. Não coloque em produção como loja até integrar provedor, webhook autenticado e controle de acesso no servidor.
- **Não há efemérides lunares nem geocodificação** nesta versão. Hora e cidade são coletadas mas não usadas nos cálculos. Nunca apresentar signo, fase, grau ou casa lunar sem cálculo astronômico validado.
- Os 12 códigos são fórmulas numerológicas **provisórias**, a validar editorialmente. Só a Câmara 1 tem prévia; as demais têm textos demonstrativos e permanecem bloqueadas.
- A biblioteca de 40 tradições está cadastrada, mas o algoritmo de afinidades ainda não foi construído.
- O projeto não armazena dados em banco nesta versão.

## Próximas etapas

1. Motor astronômico com efemérides e fuso histórico por localidade.
2. Biblioteca editorial revisada e fórmulas versionadas das 12 câmaras.
3. Backend com pedidos e acesso autenticado.
4. Checkout Mercado Pago no servidor, webhook com validação de assinatura, idempotência e verificação do status da transação via API.
5. PDF personalizado gerado no servidor após compra.
6. Política de privacidade/LGPD, exclusão de dados e testes.

Não exponha credenciais privadas do Mercado Pago no navegador.
